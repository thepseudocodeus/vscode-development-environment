# Bare Bones Live - Headless UI Components

## Launching locally

To start your Phoenix server:

* Run `mix setup` to install and setup dependencies
* Start Phoenix endpoint with `mix phx.server` or inside IEx with `iex -S mix phx.server`

Now you can visit [`localhost:4000`](http://localhost:4000) from your browser.

## Learn more

* [Mykolas Mankevicius](https://themykolas.com)
* [Buy the source code](https://mykolas.gumroad.com/l/bare-bones)
* [See it in Action](https://barebones.themykolas.com/)
