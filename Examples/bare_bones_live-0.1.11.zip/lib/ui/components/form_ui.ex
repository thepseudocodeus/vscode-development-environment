defmodule UI.Components.FormUI do
  @moduledoc false
  use UI, :component

  attr :id, :string, required: true
  attr :for, :any, required: true
  attr :class, :any, default: nil
  attr :rest, :global

  slot :inner_block, required: true

  def root(assigns) do
    ~H"""
    <.form for={@for} id={@id} class={["flex flex-col gap-6", @class]} {@rest}>
      {render_slot(@inner_block)}
    </.form>
    """
  end

  slot :inner_block, required: true

  def actions(assigns) do
    ~H"""
    <div class="flex items-center gap-4 flex-wrap">
      {render_slot(@inner_block)}
    </div>
    """
  end
end
