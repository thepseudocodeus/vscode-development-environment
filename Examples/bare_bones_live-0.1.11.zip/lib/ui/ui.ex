defmodule UI do
  @moduledoc """
  Entrypoint and module templates for Bare Bones Live components.

  UI is our app-agnostic UI component library.
  """

  @spec component() :: Macro.t()
  def component do
    quote do
      use Phoenix.Component

      alias Phoenix.LiveView.JS
      alias Phoenix.LiveView.Rendered
      alias Phoenix.LiveView.Socket

      unquote(components())
    end
  end

  @spec components() :: Macro.t()
  def components do
    quote do
      alias UI.Components.FormUI
    end
  end

  @doc """
  When used, dispatch to the appropriate module template.
  """
  defmacro __using__(which) when is_atom(which) do
    apply(__MODULE__, which, [])
  end
end
