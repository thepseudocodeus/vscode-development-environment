defmodule BareBonesLive.Repo do
  use Ecto.Repo,
    otp_app: :bare_bones_live,
    adapter: Ecto.Adapters.SQLite3
end
