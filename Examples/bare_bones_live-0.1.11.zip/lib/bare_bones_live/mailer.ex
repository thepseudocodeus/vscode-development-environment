defmodule BareBonesLive.Mailer do
  use Swoosh.Mailer, otp_app: :bare_bones_live
end
