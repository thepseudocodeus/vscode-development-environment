defmodule BareBonesLive.Tags.Tag do
  use Ecto.Schema
  import Ecto.Changeset

  schema "tags" do
    field :free_range, {:array, :string}
    field :limited_options, {:array, :string}
    field :languages, {:array, :string}

    timestamps(type: :utc_datetime)
  end

  @doc false
  def changeset(tag, attrs) do
    tag
    |> cast(attrs, [:free_range, :limited_options, :languages])
    |> validate_required([:free_range, :limited_options, :languages])
  end
end
