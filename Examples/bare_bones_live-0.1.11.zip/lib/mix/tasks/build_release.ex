defmodule Mix.Tasks.BuildRelease do
  @moduledoc """
  A Mix task to bump the project version and create a minimal ZIP archive of essential files.
  Usage: `mix build_release`
  """
  use Mix.Task

  @shortdoc "Bumps version and zips minimal project files"
  def run(_args) do
    Mix.shell().info("Starting build_release task...")

    # Step 1: Bump the version and get the new version
    case bump_version() do
      {:ok, new_version} ->
        Mix.shell().info("Version bumping completed to #{new_version}")
        # Step 2: Zip the minimal files with the new version
        case create_zip(new_version) do
          :ok -> Mix.shell().info("ZIP creation completed")
          {:error, reason} -> Mix.raise("Failed to create ZIP: #{inspect(reason)}")
        end

      {:error, reason} ->
        Mix.raise("Failed to bump version: #{inspect(reason)}")
    end
  end

  defp bump_version do
    mix_file = "mix.exs"
    Mix.shell().info("Reading mix.exs for version...")

    if File.exists?(mix_file) do
      content = File.read!(mix_file)

      # Regex to match version line
      case Regex.run(~r/version: "(\d+\.\d+\.\d+)"/, content) do
        [full_match, version] ->
          Mix.shell().info("Found version: #{version}")
          # Split version into parts and increment
          [major, minor, patch] = String.split(version, ".") |> Enum.map(&String.to_integer/1)
          new_version = "#{major}.#{minor}.#{patch + 1}"
          new_content = String.replace(content, full_match, ~s(version: "#{new_version}"))

          # Write the updated content back to mix.exs
          case File.write(mix_file, new_content) do
            :ok ->
              Mix.shell().info("Version bumped to #{new_version}")
              {:ok, new_version}

            {:error, reason} ->
              {:error, "Could not write to mix.exs: #{inspect(reason)}"}
          end

        nil ->
          {:error, "Could not find version in mix.exs"}
      end
    else
      {:error, "mix.exs not found"}
    end
  end

  defp create_zip(new_version) do
    # List of files and directories to include
    files_to_zip = [
      "assets",
      "config",
      "lib",
      "priv",
      ".tool-versions",
      "mix.exs",
      "README.md"
    ]

    # Filter only existing files/directories
    existing_files = Enum.filter(files_to_zip, &File.exists?/1)

    if Enum.empty?(existing_files) do
      Mix.shell().info("No files found to zip.")
      :ok
    else
      # Get project name from mix.exs, use the passed new_version
      project = Mix.Project.config()
      app_name = Keyword.get(project, :app, "unknown_app")
      zip_name = "#{app_name}-#{new_version}.zip"
      Mix.shell().info("Creating ZIP: #{zip_name}")

      # Convert file paths to charlists (required by :zip)
      file_list = Enum.map(existing_files, &String.to_charlist/1)

      # Use a timeout wrapper to prevent hanging
      try do
        result =
          :zip.create(String.to_charlist(zip_name), file_list, [
            {:cwd, String.to_charlist(File.cwd!())}
          ])

        case result do
          {:ok, _} ->
            Mix.shell().info("Created #{zip_name} with minimal project files")
            :ok

          {:error, reason} ->
            {:error, "ZIP creation failed: #{inspect(reason)}"}
        end
      catch
        :exit, reason ->
          {:error, "ZIP creation timed out or failed: #{inspect(reason)}"}
      end
    end
  end
end
