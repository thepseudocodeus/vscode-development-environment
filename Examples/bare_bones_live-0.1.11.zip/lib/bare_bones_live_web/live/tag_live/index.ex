defmodule BareBonesLiveWeb.TagLive.Index do
  use BareBonesLiveWeb, :live_view

  alias BareBonesLive.Tags
  alias BareBonesLive.Tags.Tag
  alias BareBonesLive.Languages

  @impl LiveView
  def render(assigns) do
    ~H"""
    <FormUI.root for={@form} id="tag-form" phx-change="validate" phx-submit="save">
      <FormUI.Tags.input
        field={@form[:free_range]}
        label="Anything Goes (List Input)"
        description="This is a tag input field. You can add as many items as you want. Press `Enter` or `Tab` to add a new item. Press backspace or click on `x` to remove an item."
      />
      <FormUI.Tags.input
        field={@form[:limited_options]}
        label="Limited Options (List Input, with options)"
        description="This is a tag input field with limited options. You can only add items from the list. Press `Enter` or `Tab` to add a new item. Press backspace or click on `x` to remove an item. Press `ESC` to close the dropdown. Note: this uses popover Api and Anchor API. Soon I will add simple absolute position option, as well as a FloatingUI option. This searches for contains rather than starts_with"
        options={@basic_options}
        search_type="contains"
      />
        <FormUI.Tags.input
        field={@form[:languages]}
        label="Languages (List Input, with options)"
        description="An example language select input"
        options={@language_options}
      />
      <FormUI.actions>
        <.button phx-disable-with="Saving...">Save</.button>
      </FormUI.actions>
    </FormUI.root>
    """
  end

  @impl LiveView
  def mount(_params, _session, socket) do
    tag = %Tag{}

    socket
    |> assign(:page_title, "Listing Tags")
    |> assign(:tag, tag)
    |> assign(:basic_options, Tags.basic_options())
    |> assign(:language_options, Languages.known_languages())
    |> assign(:form, to_form(Tags.change_tag(tag)))
    |> ok()
  end

  @impl LiveView
  def handle_event("validate", %{"tag" => tag_params}, socket) do
    socket
    |> assign(
      form:
        socket.assigns.tag
        |> Tags.change_tag(tag_params)
        |> to_form(action: :validate)
    )
    |> noreply()
  end

  def handle_event("save", %{"tag" => tag_params}, socket) do
    socket
    |> assign(
      form:
        socket.assigns.tag
        |> Tags.change_tag(tag_params)
        |> to_form(action: :validate)
    )
    |> noreply()
  end
end
