// See the Tailwind configuration guide for advanced usage
// https://tailwindcss.com/docs/configuration

const plugin = require("tailwindcss/plugin");
const fs = require("fs");
const path = require("path");

module.exports = {
  content: [
    "./js/**/*.js",
    "../lib/bare_bones_live_web.ex",
    "../lib/bare_bones_live_web/**/*.*ex",
    "../lib/ui/**/*.*ex",
  ],
  theme: {
    extend: {
      colors: {
        brand: "#FD4F00",
      },
      keyframes: {
				shake: {
					"0%": { transform: "translateX(0)" },
					"25%": { transform: "translateY(-3px)" },
					"35%": { transform: "translateY(-3px) rotate(10deg)" },
					"55%": { transform: "translateY(-3px) rotate(-10deg)" },
					"65%": { transform: "translateY(-3px) rotate(10deg)" },
					"75%": { transform: "translateY(-3px) rotate(-10deg)" },
					"100%": { transform: "translateY(0) rotate(0)" },
				},
			},
			animation: {
				shake: "shake 0.3s cubic-bezier(.36,.07,.19,.97) both",
			},
    },
  },
  plugins: [
    require("@tailwindcss/forms"),
    // Allows prefixing tailwind classes with LiveView classes to add rules
    // only when LiveView classes are applied, for example:
    //
    //     <div class="phx-click-loading:animate-ping">
    //
    plugin(({addVariant}) => addVariant("phx-click-loading", [".phx-click-loading&", ".phx-click-loading &"])),
    plugin(({addVariant}) => addVariant("phx-submit-loading", [".phx-submit-loading&", ".phx-submit-loading &"])),
    plugin(({addVariant}) => addVariant("phx-change-loading", [".phx-change-loading&", ".phx-change-loading &"])),

    // Embeds Heroicons (https://heroicons.com) into your app.css bundle
    // See your `CoreUI.icon/1` for more information.
    //
    plugin(({matchComponents, theme}) => {
      const iconsDir = path.join(__dirname, "../deps/heroicons/optimized")
      const values = {}
      const icons = [
        ["", "/24/outline"],
        ["-solid", "/24/solid"],
        ["-mini", "/20/solid"],
        ["-micro", "/16/solid"]
      ]
      for (const [suffix, dir] of icons) {
        for (const file of fs.readdirSync(path.join(iconsDir, dir))) {
          const name = path.basename(file, ".svg") + suffix
          values[name] = {name, fullPath: path.join(iconsDir, dir, file)}
        }
      }
      matchComponents({
        "hero": ({name, fullPath}) => {
          const content = fs.readFileSync(fullPath).toString().replace(/\r?\n|\r/g, "")
          let size = theme("spacing.6")
          if (name.endsWith("-mini")) {
            size = theme("spacing.5")
          } else if (name.endsWith("-micro")) {
            size = theme("spacing.4")
          }
          return {
            [`--hero-${name}`]: `url('data:image/svg+xml;utf8,${content}')`,
            "-webkit-mask": `var(--hero-${name})`,
            "mask": `var(--hero-${name})`,
            "mask-repeat": "no-repeat",
            "background-color": "currentColor",
            "vertical-align": "middle",
            "display": "inline-block",
            "width": size,
            "height": size
          }
        }
      }, {values})
    })
  ]
}
