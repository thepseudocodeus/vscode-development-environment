import { normalizeText } from "../hooks/utils";

export class TextHighlight extends HTMLElement {
  static get observedAttributes() {
    return ['value', 'normalize', 'element-selector', 'highlight-class'];
  }

  public static clear() {
    CSS.highlights.clear();
  }

  connectedCallback() {
    this.updateHighlighting();
  }

  disconnectedCallback() {
    TextHighlight.clear();
  }

  attributeChangedCallback(_name: string, oldValue: string, newValue: string) {
    if (oldValue !== newValue) {
      this.updateHighlighting();
    }
  }

  private get shouldNormalize() {
    const normalizeAttr = this.getAttribute('normalize');
    return normalizeAttr === 'true' || normalizeAttr === '';
  }

  private get highlightClass() {
    return this.getAttribute('highlight-class') ?? 'text-highlight';
  }


  private get options() {
    const selector = this.getAttribute('element-selector') ?? 'highlight-element';
    if (!selector) return [];
    return Array.from(document.querySelectorAll(`[${selector}]`));
  }

  private get optionsTextNodes() {
    const allTextNodes: Node[] = [];
    for (const option of this.options) {
      const treeWalker = document.createTreeWalker(option, NodeFilter.SHOW_TEXT);
      let currentNode = treeWalker.nextNode();
      while (currentNode) {
        allTextNodes.push(currentNode);
        currentNode = treeWalker.nextNode();
      }
    }
    return allTextNodes;
  }


  private normalizeText = (value: string): string => {
    return this.shouldNormalize ? value : normalizeText(value)
  }

  private highlight = (query: string) => {
    CSS.highlights.clear();

    if (!query) return;

    const search = this.normalizeText(query)

    const ranges = this.optionsTextNodes
      .map((el) => ({
        el,
        text: el.textContent ? this.normalizeText(el.textContent) : ''
      }))
      .filter(({ text }) => text.includes(search))
      .map(({ text, el }) => {
        const indices: number[] = [];
        let startPos = 0;
        while (startPos < text.length) {
          const index = text.indexOf(search, startPos);
          if (index === -1) break;
          indices.push(index);
          startPos = index + search.length;
        }

        return indices.map((index) => {
          const range = new Range();
          range.setStart(el, index);
          range.setEnd(el, index + search.length);
          return range;
        });
      });

    CSS.highlights.set(this.highlightClass, new Highlight(...ranges.flat()));
  }

  updateHighlighting() {
    const value = this.getAttribute('value') || '';
    this.highlight(value);
  }
}

customElements.define('text-highlight', TextHighlight);
