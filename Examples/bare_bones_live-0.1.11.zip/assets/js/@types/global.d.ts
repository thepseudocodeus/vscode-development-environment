import type { LiveSocket } from 'phoenix_live_view'

type LiveReloader = {
  enableServerLogs: () => void
  disableServerLogs: () => void
  openEditorAtCaller: (target: EventTarget | null) => void
  openEditorAtDef: (target: EventTarget | null) => void
}

declare global {
  interface Window {
    liveSocket?: LiveSocket & { execJS?: (el: HTMLElement, cmd: string, eventType?: string) => void }
    execJS: (el: HTMLElement | null | undefined, cmd: string, eventType?: string) => void
    liveReloader?: LiveReloader
  }

  interface WindowEventMap {
    'phx:live_reload:attached': CustomEvent<LiveReloader>
    'phx:exec_js': CustomEvent<{ id: string; cmd: string; eventType?: string }>
    'mrk:copy': CustomEvent
    'mrk:scroll-into-view': CustomEvent<{
      behavior?: ScrollBehavior
      block?: ScrollLogicalPosition
      inline?: ScrollLogicalPosition
      offset?: string
    }>
  }
}
