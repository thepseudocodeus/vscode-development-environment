import { LiveViewHook } from './LiveViewHook';
import type { TagsHook } from './TagsHook';
import { getHookInstance, requiredAttr } from './utils';


type SearchType = 'starts_with' | 'contains';

const OPTIONS_LIMIT_INPUT = 'options-limit-input';
const OPTIONS_KEEP_OPEN_AFTER_ADD = 'options-keep-open-after-add';
const OPTIONS_LOOP_ON_KEYDOWN = 'options-loop-on-keydown';
const OPTIONS_SEARCH_TYPE = 'options-search-type';
const ITEM_EL = '[options-item]';
const NO_RESULTS_EL = '[options-no-results]';

const DATA_VALUE_ATTR = 'data-value'
const DATA_LABEL_ATTR = 'data-label'
const DATA_FOCUS_ATTR = 'data-focus'
const DATA_ACTIVE_ATTR = 'data-active'

class TagsInputOptionsHook extends LiveViewHook {
  root: TagsHook;
  focusedOption: HTMLElement | null = null;
  isOpen = false;

  mounted() {
    this.setup();
  }

  updated() {
    this.teardown();
    this.setup();
    console.log('updated', this.isOpen)
    if (this.isOpen) {
      this.filterOptions()
    }
  }

  destroyed() {
    this.teardown();
  }

  private get popover() { return this.el.hasAttribute('popover') }
  private get options() { return this.el.querySelectorAll<HTMLLIElement>(ITEM_EL); }
  private get noResults() { return this.el.querySelectorAll<HTMLElement>(NO_RESULTS_EL); }
  private get searchType() { return this.optionalAttr<SearchType>(OPTIONS_SEARCH_TYPE, "starts_with"); }
  private get optionsOnly() { return this.el.hasAttribute(OPTIONS_LIMIT_INPUT); }
  private get keepOpenAfterAdd() { return this.el.hasAttribute(OPTIONS_KEEP_OPEN_AFTER_ADD); }
  private get loopOptions() { return this.el.hasAttribute(OPTIONS_LOOP_ON_KEYDOWN); }
  private get input() { return this.root.input }
  private get inputValue() { return this.root.inputValue }

  private normalizeText = (value: string) => {
    return this.root.normalizeText(value)
  };

  private addItem = (value: string) => {
    this.root.addItem(value)
  };


  private setup = () => {
    // Find the parent element with phx-hook="TagsHook"
    const tagsHook = getHookInstance<TagsHook>(this.el, "TagsHook")
    if (tagsHook) {
      this.root = tagsHook;
    } else {
      throw new Error('[TagsInputOptionsHook] element must be a child of [TagsHook]');
    }


    this.root.registerClickOutsideListener(this.handleClickOutside)

    this.input.addEventListener('focus', this.filterOptions);
    this.input.addEventListener('input', this.filterOptions);
    this.input.addEventListener('keydown', this.handleKeydown);
    this.el.addEventListener('click', this.handleOptionClick);
  }

  private teardown = () => {
    this.input.removeEventListener('focus', this.filterOptions);
    this.input.removeEventListener('input', this.filterOptions);
    this.input.removeEventListener('keydown', this.handleKeydown);
    this.el.removeEventListener('click', this.handleOptionClick);
  }

  private hideOptions = () => {
    this.hide();
    this.clearOptionFocus();
    this.clearFilterAttributes();
  };

  private show = () => {
    this.isOpen = true;
    if (this.popover) {
      this.el.showPopover();
    } else {
      this.el.setAttribute('open', '');
    }
  };

  private hide = () => {
    this.isOpen = false;
    if (this.popover) {
      this.el.hidePopover();
    } else {
      this.el.removeAttribute('open');
    }
  };


  private handleClickOutside = () => {
    this.hideOptions()
    this.input.value = ''
  }


  private filterOptions = () => {
    this.show();
    const search = this.normalizeText(this.inputValue);

    if (!search) {
      this.updateNoResults(false)
      this.clearFilterAttributes();
      this.clearOptionFocus();
      // CSS.highlights.clear();
      return;
    }

    let hasActive = false;
    let firstMatch: HTMLLIElement | null = null;

    for (const option of this.options) {
      if (this.optionMatchesSearch(option, search)) {
        option.setAttribute(DATA_ACTIVE_ATTR, 'true');
        firstMatch = firstMatch === null ? option : firstMatch

        hasActive = true;
      } else {
        option.setAttribute(DATA_ACTIVE_ATTR, 'false');
      }
    }

    if (firstMatch) {
      this.focusOption(firstMatch);
    }

    this.updateNoResults(!hasActive)
    if (!hasActive) {
      this.clearOptionFocus()
    }
  };

  private optionMatchesSearch = (option: HTMLLIElement, search: string) => {
    const label = this.normalizeText(requiredAttr(option, DATA_LABEL_ATTR));

    switch (this.searchType) {
      case "starts_with":
        return label.startsWith(search);

      case "contains":
        return label.includes(search);

      default:
        return label.startsWith(search);
    }
  };

  private updateNoResults(active: boolean) {
    for (const element of this.noResults) {
      element.toggleAttribute(DATA_ACTIVE_ATTR, active);
    }
  }

  private handleKeydown = (event: KeyboardEvent) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      if (this.focusedOption) {
        this.addItem(requiredAttr(this.focusedOption, DATA_VALUE_ATTR))
        if (!this.keepOpenAfterAdd) this.hideOptions();
        return
      }

      if (this.inputValue && !this.optionsOnly) {
        this.addItem(this.inputValue);
      }

      return;
    }

    if (event.key === 'Tab') {
      if (event.shiftKey || !this.focusedOption) {
        this.hideOptions();
        return
      }

      this.addItem(requiredAttr(this.focusedOption, DATA_VALUE_ATTR))
      this.hideOptions();
      this.input.value = '';
    }

    if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
      event.preventDefault();
      this.navigateOptions(event.key === 'ArrowDown');
    }

    if (event.key === 'Escape' && this.isOpen) {
      event.preventDefault();
      this.hideOptions();
      this.root.input.focus();
    }
  };

  private handleOptionClick = (event: Event) => {
    if (!this.isOpen) return;

    const option = (event.target as Element).closest(ITEM_EL);
    if (!option) {
      return;
    }

    this.focusedOption = option as HTMLElement;
    this.addItem(requiredAttr(option, DATA_VALUE_ATTR));
    if (!this.keepOpenAfterAdd) this.hideOptions();
    this.input.focus();
  };

  private navigateOptions = (down: boolean) => {
    const activeOptions = Array.from(this.el.querySelectorAll<HTMLElement>(`${ITEM_EL}[${DATA_ACTIVE_ATTR}="true"]`));
    if (!activeOptions.length) return;

    let newIndex = this.focusedOption ? activeOptions.indexOf(this.focusedOption) : -1;

    // If no focusedOption, start from the first active option (index 0)
    if (newIndex === -1) {
      this.focusOption(activeOptions[0]);
      return;
    }

    const loop = this.loopOptions;
    if (down) {
      newIndex = (newIndex + 1) % activeOptions.length;
      if (newIndex === 0 && !loop) newIndex = activeOptions.length - 1;
    } else {
      newIndex = (newIndex - 1 + activeOptions.length) % activeOptions.length;
      if (newIndex === activeOptions.length - 1 && !loop) newIndex = 0;
    }

    this.focusOption(activeOptions[newIndex]);
  };

  private clearOptionFocus = () => {
    if (this.focusedOption) {
      this.focusedOption.removeAttribute(DATA_FOCUS_ATTR);
      this.focusedOption = null;
    }
  };

  private focusOption = (option: HTMLElement) => {
    this.clearOptionFocus();
    this.focusedOption = option;
    this.focusedOption.setAttribute(DATA_FOCUS_ATTR, '');
    this.focusedOption.scrollIntoView({ behavior: 'instant', block: 'nearest' });
  }


  private clearFilterAttributes = () => {
    for (const option of this.options) {
      option.setAttribute(DATA_ACTIVE_ATTR, 'true');
    }

    this.updateNoResults(false)
  };
}

export default TagsInputOptionsHook.createViewHook();
