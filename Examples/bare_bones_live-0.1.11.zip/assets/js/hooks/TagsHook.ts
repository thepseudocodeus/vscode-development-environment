import { LiveViewHook } from './LiveViewHook';
import { normalizeText } from './utils';

const TAGS_INPUT_ID_ATTR = 'tags-input-id';
const TAGS_EMPTY_INPUT = '[tags-empty-input]';
const TAGS_TEMP_VALUE_INPUT = 'tags-temp-value-input';
const INPUT_NAME_ATTR = 'tags-input-name';
const MAX_ITEMS_ATTR = 'tags-max-items';
const CASE_SENSITIVE_ATTR = 'tags-case-sensitive';
const REMOVE_ON_BACKSPACE = 'tags-remove-on-backspace';
const DATA_TAGS_PREVENT_INPUT_ADD = 'tags-prevent-input-add';

const ITEM = '[tags-item]';
const ITEM_REMOVE = 'button[tags-item-remove]'
const ITEM_ANIMATE_DUPLICATE = 'animate-duplicate';
const ITEM_DATA_DUPLICATE = 'data-duplicate';

export class TagsHook extends LiveViewHook {
  input!: HTMLInputElement;
  emptyInput!: HTMLInputElement;
  private globalClickHandler: ((event: MouseEvent) => void) | null = null;
  private clickOutsideListeners = new Set<() => void>()

  // Region Public
  public get inputValue() {
    return this.input.value.trim();
  }

  public registerClickOutsideListener = (callback: () => void) => {
    this.clickOutsideListeners.add(callback)
  }

  public normalizeText = (value: string): string => {
    return this.caseSensitive ? value : normalizeText(value)
  };

  // Region Hook
  mounted() {
    this.input = this.requiredChild(`#${this.requiredAttr(TAGS_INPUT_ID_ATTR)}`, HTMLInputElement);
    this.emptyInput = this.requiredChild(TAGS_EMPTY_INPUT, HTMLInputElement);
    this.input.addEventListener('keydown', this.handleKeydown);
    this.input.addEventListener('input', this.preventDefault());
    this.input.addEventListener('change', this.preventDefault());
    this.input.addEventListener('focus', this.startWatchingOutsideClicks);

    if (!this.preventInputAdd) {
      this.registerClickOutsideListener(this.handleClickOutside)
    }

    this.el.addEventListener('click', this.handleClick);
  }

  destroyed() {
    this.input.removeEventListener('keydown', this.handleKeydown);
    this.input.removeEventListener('focus', this.startWatchingOutsideClicks);
    this.input.removeEventListener('input', this.preventDefault());
    this.input.removeEventListener('change', this.preventDefault());
    this.el.removeEventListener('click', this.handleClick);
    this.removeGlobalClickHandler();
    this.clickOutsideListeners.clear()
  }

  // Region Private
  private get caseSensitive() {
    return this.optionalAttr<'true' | 'false'>(CASE_SENSITIVE_ATTR, 'false') === 'true';
  }

  private get preventInputAdd() {
    return this.el.hasAttribute(DATA_TAGS_PREVENT_INPUT_ADD);
  }

  private get currentItems() {
    return [...Array.from(this.el.querySelectorAll<HTMLInputElement>(`${ITEM} input[type="hidden"]`)),
    ...Array.from(this.el.querySelectorAll<HTMLInputElement>(`input[type="hidden"][${TAGS_TEMP_VALUE_INPUT}]`))
    ];
  }

  private get currentValues() {
    return this.currentItems.map(input => this.normalizeText(input.value.trim()));
  }

  private get maxItems() {
    const maxItems = this.el.getAttribute(MAX_ITEMS_ATTR);
    return maxItems ? Number.parseInt(maxItems, 10) : Number.POSITIVE_INFINITY;
  }

  private get removeOnBackspace() {
    return this.optionalAttr<"true" | "false">(REMOVE_ON_BACKSPACE, "false") !== 'false';
  }

  private preventDefault = () => (event: Event) => {
    event.stopPropagation();
  }

  private removeGlobalClickHandler = () => {
    if (this.globalClickHandler) {
      document.removeEventListener('click', this.globalClickHandler);
      this.globalClickHandler = null;
    }
  }

  private handleClickOutside = () => {
    this.addItem(this.inputValue);
  }

  private handleKeydown = (event: KeyboardEvent) => {
    if ((event.key === 'Enter' || event.key === 'Tab') && this.preventInputAdd) {
      return;
    }

    if (event.key === 'Enter') {
      event.preventDefault();
      this.addItem(this.inputValue);
    }

    if (event.key === 'Tab' && !event.shiftKey && !event.ctrlKey && !event.altKey && !event.metaKey) {
      this.addItem(this.inputValue);
    }

    if (event.key === 'Backspace' && this.inputValue === '' && this.removeOnBackspace) {
      this.removeLastItem();
    }
  };

  private startWatchingOutsideClicks = () => {
    if (this.globalClickHandler) return;


    this.globalClickHandler = (event: MouseEvent) => {
      const target = event.target as Node;
      const inputId = this.input.id;
      const associatedLabel = document.querySelector(`label[for="${inputId}"]`);

      if (this.el.contains(target) || associatedLabel?.contains(target)) {
        return;
      }

      for (const callback of this.clickOutsideListeners) {
        callback()
      }

      this.removeGlobalClickHandler();
    };

    document.addEventListener('click', this.globalClickHandler, { passive: true });
  }

  private handleClick = (event: Event) => {
    const button = (event.target as Element).closest(ITEM_REMOVE);
    if (button) {
      event.stopImmediatePropagation();
      const itemContainer = button.closest(ITEM);
      const itemValue = itemContainer?.querySelector<HTMLInputElement>('input[type="hidden"]')?.value;
      if (itemValue) {
        const inputValue = this.input.value || '';
        this.removeItemByValue(itemValue);
        this.input.value = inputValue;
        this.input.focus();
      }
      return;
    }

    this.input.focus();
  };

  private createItemElement = (item: string) => {
    const itemElement = document.createElement('input');
    itemElement.type = 'hidden';
    itemElement.setAttribute(TAGS_TEMP_VALUE_INPUT, "");
    itemElement.name = this.requiredAttr(INPUT_NAME_ATTR);
    itemElement.value = item;
    return itemElement;
  };

  private itemByValue = (value: string) => {
    const normalizedValue = this.normalizeText(value);
    const selector = `${ITEM} input[type="hidden"]`;
    const items = this.el.querySelectorAll<HTMLInputElement>(selector);

    for (const item of items) {
      if (this.normalizeText(item.value) === normalizedValue) {
        return item.closest(ITEM);
      }
    }

    return null;
  }

  public addItem = (value: string) => {
    if (value === '') return;

    const values = this.currentValues;

    if (values.length >= this.maxItems) return;

    if (values.includes(this.normalizeText(value))) {
      this.markExistingItem(value);
      return;
    }

    const itemElement = this.createItemElement(value);
    this.el.appendChild(itemElement);
    itemElement.dispatchEvent(new Event('change', { bubbles: true }));
    this.input.value = '';
  }

  private removeItemByValue = (value: string) => {
    this.removeItem(this.itemByValue(value))
  }

  private removeLastItem = () => {
    this.removeItem(this.el.querySelector(`${ITEM}:last-of-type`))
  }

  private removeItem = (itemElement?: Element | null) => {
    if (!itemElement) return;
    itemElement.remove();
    this.notifyChange();
  }

  private notifyChange = () => {
    const inputs = this.currentItems;
    if (inputs.length === 0) {
      this.emptyInput.disabled = false;
      this.emptyInput.dispatchEvent(new Event('change', { bubbles: true }));
      requestAnimationFrame(() => { this.emptyInput.disabled = true });

    } else {
      const [firstInput] = inputs;
      firstInput.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }

  private markExistingItem = (value: string) => {
    const existingElement = this.itemByValue(value);
    if (!existingElement || !existingElement.hasAttribute(ITEM_ANIMATE_DUPLICATE)) {
      return;
    }

    existingElement.setAttribute(ITEM_DATA_DUPLICATE, '');

    const handleAnimationEnd = () => {
      existingElement.removeAttribute(ITEM_DATA_DUPLICATE);
      existingElement.removeEventListener('animationend', handleAnimationEnd);
    };

    existingElement.addEventListener('animationend', handleAnimationEnd);
  }
}

export default TagsHook.createViewHook();
