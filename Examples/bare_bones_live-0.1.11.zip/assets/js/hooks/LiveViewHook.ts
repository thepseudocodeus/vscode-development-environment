import type { ViewHook } from 'phoenix_live_view'
import { optionalAttr, requiredAttr, requiredEl } from './utils'

interface Hook<T> extends ViewHook {
  instance: T | null
}

type OnReply = (reply: unknown, ref: number) => unknown

export abstract class LiveViewHook<T extends HTMLElement = HTMLElement> {
  protected el: T
  protected hook: ViewHook

  mounted(): void { }
  beforeUpdate(): void { }
  updated(): void { }
  beforeDestroy(): void { }
  destroyed(): void { }
  disconnected(): void { }
  reconnected(): void { }

  constructor(hook: ViewHook) {
    this.hook = hook
    this.el = hook.el
  }

  protected pushToServer(event: string, payload: object = {}, onReply?: OnReply) {
    const targetView = this.el.getAttribute('phx-target') ?? this.el.getAttribute('data-target')
    if (targetView === null || targetView === '') {
      this.hook.pushEvent(event, payload, onReply)
      return
    }

    this.hook.pushEventTo(targetView, event, payload, onReply)
  }

  protected handleEvent<T extends object>(event: string, callback: (payload: T) => void): void {
    this.hook.handleEvent(event, (payload: object) => callback(payload as T))
  }

  protected readonly requiredAttr = <T extends string>(attribute: string): T => requiredAttr<T>(this.el, attribute)
  protected readonly optionalAttr = <T extends string>(attribute: string, fallback: T): T =>
    optionalAttr<T>(this.el, attribute, fallback)

  protected readonly requiredChild = <T extends HTMLElement>(
    selector: string,
    type: { new(): T } = HTMLElement as unknown as { new(): T }
  ): T => {
    return requiredEl<T>(this.el.querySelector<T>(selector), type)
  }

  protected readonly requiredChildren = <T extends HTMLElement>(
    selector: string,
    type: { new(): T } = HTMLElement as unknown as { new(): T }
  ): T[] => {
    const childrenElements = Array.from(this.el.querySelectorAll<T>(selector))

    if (childrenElements.every((element) => requiredEl<T>(element, type))) {
      return childrenElements
    }

    throw new Error(`All child elements must be of type: ${type.name}`)
  }

  static createViewHook<T extends LiveViewHook>(this: new (hook: ViewHook) => T): Hook<T> {
    const HookClass = this as unknown as new (hook: ViewHook) => T

    return {
      instance: null,

      mounted() {
        this.instance = new HookClass(this)
        this.instance.mounted()
      },
      beforeUpdate() {
        this.instance?.beforeUpdate()
      },
      updated() {
        this.instance?.updated()
      },
      beforeDestroy() {
        this.instance?.beforeDestroy()
      },
      destroyed() {
        this.instance?.destroyed()
        this.instance = null
      },
      disconnected() {
        this.instance?.disconnected()
      },
      reconnected() {
        this.instance?.reconnected()
      }
    } as Hook<T>
  }
}
