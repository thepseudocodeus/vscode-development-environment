import type { LiveSocket } from 'phoenix_live_view'

declare global {
  interface Window {
    liveSocket?: LiveSocket
  }
}

type HookElement = HTMLElement & { phxPrivate?: { hookId: number } }

export const requiredEl = <T extends HTMLElement>(
  element: unknown,
  type: { new(): T } = HTMLElement as unknown as { new(): T }
): T => {
  if (!element) {
    throw new Error(`Element must exist ${type.name}`)
  }

  if (!(element instanceof type)) {
    throw new Error(`Element must be of type ${type.name}`)
  }

  return element
}

export const requiredAttr = <T extends string>(el: Element, attribute: string): T => {
  const value = el.getAttribute(attribute)
  if (!value) {
    throw new Error(`Attribute must exist: ${attribute}`)
  }
  return value as T
}

export const optionalAttr = <T extends string>(el: Element, attribute: string, fallback: T): T =>
  (el.getAttribute(attribute) ?? fallback) as T


// This can be fragile and can change with Phoenix versions until we get a nicer way to interact with it
export const getHookInstance = <T>(element: Element, hookName: string): T | null => {
  const hookElementSelf = element.id ? document.querySelector(`#${element.id}[phx-hook="${hookName}"]`) : null
  const hookElement = (hookElementSelf ?? element.closest(`[phx-hook="${hookName}"]`)) as HookElement
  return (window.liveSocket?.main?.viewHooks[hookElement.phxPrivate?.hookId ?? -1].instance as T) ?? null
}


export const normalizeText = (value: string): string => {
  // Remove diacritics (accents, umlauts, etc.) and convert to lowercase
  return value
    .trim()
    .normalize('NFD') // Decompose characters into base + diacritics
    .replace(/[\u0300-\u036f]/g, '') // Remove diacritic marks
    .replace(/[^a-zA-Z0-9\s]/g, '') // Remove all special characters except letters, numbers, and whitespace
    .toLowerCase()
}
